import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;

public class Addr_ma_sys extends JFrame {

    JTextField tfName, tfTel, tfCom, tfSearch;
    JTextArea ta;
    JButton btnInsert, btnSelect, btnSearch, btnUpdate, btnDelete, btnExit;
    Connection conn;
    PreparedStatement pstmt;
    ResultSet rs;

    public Addr_ma_sys() {
        setTitle("homework");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        createGUI();
        setSize(300, 400);
        setResizable(false);
        setVisible(true);

        // 버튼 이벤트 연결
        btnInsert.addActionListener(e -> dbInsert());
        btnSelect.addActionListener(e -> dbSelect());
        btnSearch.addActionListener(e -> dbSearch());
        btnUpdate.addActionListener(e -> dbUpdate());
        btnDelete.addActionListener(e -> dbDelete());
        btnExit.addActionListener(e -> System.exit(0));
    }

    public void createGUI() {
        setLayout(new BorderLayout());

        // 📌 입력 영역 (이름/전화번호/회사이름)
        JPanel inputPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        inputPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 0, 10));

        inputPanel.add(new JLabel("이름"));
        tfName = new JTextField();
        inputPanel.add(tfName);

        inputPanel.add(new JLabel("전화번호"));
        tfTel = new JTextField();
        inputPanel.add(tfTel);

        inputPanel.add(new JLabel("회사이름"));
        tfCom = new JTextField();
        inputPanel.add(tfCom);

        add(inputPanel, BorderLayout.NORTH);

        // 📌 버튼 6개 (2열 3행)
        JPanel btnPanel = new JPanel(new GridLayout(3, 2, 5, 5));
        btnPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btnInsert = new JButton("입력");
        btnSelect = new JButton("조회");
        btnSearch = new JButton("검색");
        btnUpdate = new JButton("수정");
        btnDelete = new JButton("삭제");
        btnExit = new JButton("종료");

        btnPanel.add(btnInsert);
        btnPanel.add(btnSelect);
        btnPanel.add(btnSearch);
        btnPanel.add(btnUpdate);
        btnPanel.add(btnDelete);
        btnPanel.add(btnExit);

        add(btnPanel, BorderLayout.CENTER);

        // 📌 검색용 입력 필드와 출력창
        JPanel bottomPanel = new JPanel(new BorderLayout());
        tfSearch = new JTextField();
        bottomPanel.add(tfSearch, BorderLayout.NORTH);

        ta = new JTextArea(8, 25);
        ta.setEditable(false);
        JScrollPane scroll = new JScrollPane(ta);
        bottomPanel.add(scroll, BorderLayout.CENTER);

        add(bottomPanel, BorderLayout.SOUTH);
    }

    public Connection dbConnect() {
        Connection conn = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            String url = "jdbc:mysql://localhost:3306/mydb?serverTimezone=Asia/Seoul";
            String user = "root";
            String password = "dongyang";
            conn = DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "DB 연결 실패");
        }
        return conn;
    }

    public void dbInsert() {
        try {
            conn = dbConnect();
            String sql = "INSERT INTO addrtbl (name, tel, com) VALUES (?, ?, ?)";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfName.getText());
            pstmt.setString(2, tfTel.getText());
            pstmt.setString(3, tfCom.getText());
            pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "입력 완료");
            tfName.setText("");
            tfTel.setText("");
            tfCom.setText("");
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dbSelect() {
        try {
            conn = dbConnect();
            String sql = "SELECT * FROM addrtbl";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            ta.setText(" id | 이름 | 전화번호 | 회사 | 등록일\n");
            ta.append("------------------------------------------\n");
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String tel = rs.getString("tel");
                String com = rs.getString("com");
                Timestamp inDate = rs.getTimestamp("inData");
                ta.append(String.format(" %d | %s | %s | %s | %s\n", id, name, tel, com, inDate));
            }
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dbSearch() {
        try {
            conn = dbConnect();
            String sql = "SELECT * FROM addrtbl WHERE name = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfSearch.getText());
            rs = pstmt.executeQuery();
            ta.setText(" id | 이름 | 전화번호 | 회사 | 등록일\n");
            ta.append("------------------------------------------\n");
            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String tel = rs.getString("tel");
                String com = rs.getString("com");
                Timestamp inDate = rs.getTimestamp("inData");
                ta.append(String.format(" %d | %s | %s | %s | %s\n", id, name, tel, com, inDate));
            }
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dbUpdate() {
        try {
            conn = dbConnect();
            String sql = "UPDATE addrtbl SET tel = ?, com = ? WHERE name = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfTel.getText());
            pstmt.setString(2, tfCom.getText());
            pstmt.setString(3, tfName.getText());
            int rows = pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "수정 완료" : "수정 실패");
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void dbDelete() {
        try {
            conn = dbConnect();
            String sql = "DELETE FROM addrtbl WHERE name = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, tfName.getText());
            int rows = pstmt.executeUpdate();
            JOptionPane.showMessageDialog(this, rows > 0 ? "삭제 완료" : "삭제 실패");
            tfName.setText("");
            tfTel.setText("");
            tfCom.setText("");
            pstmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new Addr_ma_sys();
    }
}
